# pkg
implement steps to build packages.

在这几个实验中，发现文件的布局非常重要。
按照官网中 [包发现和命名空间包](https://setuptools.pypa.io/en/latest/userguide/package_discovery.html#finding-namespace-packages)  的描述，选择 src 布局是明智的选择。
![Alt text](image.png)

mmdetection 用的是 平面布局

![Alt text](image-1.png)



## 打包& 安装
```
python -m build
 
pip install ./dist/pk7-0.1-py3-none-any.whl 
```

在具体实验中，pkgg 可以正常 import pkgg
pk5 可以正常 import kk5(!不能导入 pk5)
可以从 pk5.egg-info/top_level.txt 中看到 kk5. 
